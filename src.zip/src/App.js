import './App.css';
import PropertyDetails from './Components/PropertyDetails';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import RenderComponets from './Components/RenderComponets';

function App() {
  return (
 <>  
 <div>
     
 <Router>
      <Routes>
              <Route exact path="/" element={<RenderComponets/>}></Route>
              <Route path='/propertydetails' element={<PropertyDetails/>}></Route>
        </Routes>
  </Router>
  </div> 
 
    
   
  </>
  );
}

export default App;
