  import React from 'react';

function Header() {
  return (
    <>
   <nav className='navbar navbar-dark navbar-expand-lg bg-dark'>
        <div className='navbar-brand d-inline-block'>
        <img src="Images/Ramanasoftlogo.jpg" alt="Description of the image" />

            <h3 className='ms-5'>RS Insurance Company</h3>
        </div>
        <div className='ms-auto'> 
            <button className='btn btn-primary me-4 ' >Admin</button>
        </div>

   </nav>
      
    </>
  );
}

export default Header;
