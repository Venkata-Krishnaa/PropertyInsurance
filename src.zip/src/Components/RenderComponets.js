import React from 'react';
import Header from './Header';
import SideNav from './SideNav';
import LoginForm from './LoginForm';

function RenderComponets() {
  return (
    <div className='image-container'>
      <Header/>
     <div className='container mt-5  '>
     
        <div className='row'>
          
          <div className='col-9 border border-dark rounded border-3 '>
              <SideNav/>
          </div> 
          <div className='col-3 mbs'>
            <LoginForm/>
          </div>

        </div>
    </div>
    </div>
  );
}

export default RenderComponets;
