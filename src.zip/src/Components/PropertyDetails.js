import React from 'react';

function PropertyDetails() {
  return (
    <div>
   
   propertydetails
    </div>
  );
}

export default PropertyDetails;
